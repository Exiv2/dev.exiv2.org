# Content-Type: text/plain; charset=utf8
# -*- coding: utf-8 -*-

from gi.repository import Gtk
from gi.repository.GdkPixbuf import Pixbuf
import os, sys, webbrowser
import subprocess
import datetime 
from subprocess import Popen, PIPE, call, STDOUT
from os.path import abspath, dirname, join
import locale
import gettext
from gettext import gettext as _


#    Graphic User Interface to exiv2 for Image Metadata Editing in Python

#    Copyright © 2004-2016  Richard Blaikie, Ontario, Canada

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, version 3 of the License.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

WHERE_AM_I = abspath(dirname(__file__))
EXIV2_LOCATION = '/usr/bin/exiv2'
APP = 'exifgui'
PROGDIR = '/usr/share/' + APP + '/'
LOCALEDIR = "/usr/share/locale/"
DISPLAYNAME = "ExifGUI"
VERSION = "0.2-1"
WEBSITE = "No Website Yet"
DONATE = "https://www.paypal.com/xclick/business=hugh_switzerland@hotmail.com"


class Exifgui():
    def __init__(self):

        # Build GUI
        self.builder = Gtk.Builder()
        self.glade_file = join(WHERE_AM_I, APP + '.glade')
        self.builder.add_from_file(self.glade_file)

        # Set locale
        locale.setlocale(locale.LC_ALL, '')
        locale.bindtextdomain(APP, LOCALEDIR)
        gettext.bindtextdomain(APP, LOCALEDIR)
        gettext.textdomain(APP)
        self.builder.set_translation_domain(APP)
        # print locale.getlocale()

        # Get objects
        go = self.builder.get_object
        self.aboutdialog1 = go("aboutdialog1")
        self.success_dialog = go("success_dialog")
        self.ok_msg = go('ok_msg')
        self.emergency_dialog = go("emergency_dialog")
        self.err_msg = go('err_msg') 

        self.select_window = go('select_window')
        self.window_picchange = go('window_picchange')
        self.filechanges = go("filechanges")
# For mime type selection
        self.mymime_store = go('mymime_store')
        self.mymimetype = go('mymimetype')
# For Exif tag field selection
        self.myexiftags_store = go('myexiftags_store')
        self.myexiffield = go('myexiffield')
# For Exif tag selection action
        self.myexif_compare = go('myexif_compare')
        self.myselection = go('myselection')
# Read the standard Exif tags from the configuration file
        file = open(PROGDIR + os.sep + APP + '.conf', 'r')
        result = ((file.read()).replace("\n","|")).split('|')
        file.close()
        self.myexiftags_store.append([_("Select Field")])
        for t in result:
          if t:
            self.myexiftags_store.append([t])

# For Exif metadata view window
        self.tag = 0
        self.window_meta = go('window_meta')
        self.mytree_store = go('mytree_store')
        self.list = go('list')
        self.headerlabel = go('headerlabel')
        column = Gtk.TreeViewColumn(_('Exif Tag'), Gtk.CellRendererText(), text=0)   
        column.set_clickable(True)   
        column.set_resizable(True)   
        self.list.append_column(column)
        column = Gtk.TreeViewColumn(_('Tag type'), Gtk.CellRendererText(), text=1)   
        column.set_clickable(True)   
        column.set_resizable(True)   
        self.list.append_column(column)
        column = Gtk.TreeViewColumn(_('Tag Length'), Gtk.CellRendererText(), text=2)   
        column.set_clickable(True)   
        column.set_resizable(True)   
        self.list.append_column(column)
        column = Gtk.TreeViewColumn(_('Tag Value'), Gtk.CellRendererText(), text=3)   
        column.set_clickable(True)   
        column.set_resizable(True)
        self.list.append_column(column)

        self.inputdirbutton = go("inputdirbutton")
        self.includesubfolder = go("includesubfolder")
        self.exifvalue = go("exifvalue")

        self.clickprevious = go("clickprevious")
        self.clicknext = go("clicknext")
        self.exifdata = go('exifdata')

        self.filecount = go("filecount")
        self.browse_meta = go("browse_meta")
        self.search_files = go("search_files")
        self.next_step = go("next_step")

        self.file_names = []

        # Initialize interfaces
        self.mimetype = [
 [_('Select'), _('None')],
 [_('Jpeg files'), 'JPG jpg JPEG jpeg JPE jpe'],
 [_('Png files'), 'PNG png'],
 [_('Gif files'), 'GIF gif'],
 [_('Tif files'), 'TIF tif TIFF tiff'],
        ]

        self.selecttype = [
 [_('Action'), _('None')],
 [_('Equal to'), '='],
 [_('Not equal to'), '<>'],
 [_('Is less than'), '<'],
 [_('Is greater than'), '>'],
 [_('Is empty'), 'is none'],
 [_('Is not empty'), 'not none'],
        ]

        self.renameformat = [
 [_('Select'), _('Select Format')],
 ['YYYY-MM-DD_HH.MM.SS', '%Y-%m-%d_%H.%M.%S'],
 ['YYYY-MM-DD_HH:MM:SS', '%Y-%m-%d_%H:%M:%S'],
 ['YYYY-MM-DD_HHMMSS', '%Y-%m-%d_%H%M%S'],
 ['YYYY-MM-DD HH.MM.SS', '%Y-%m-%d %H.%M.%S'],
 ['YYYY-MM-DD HH:MM:SS', '%Y-%m-%d %H:%M:%S'],
 ['YYYY-MM-DD HHMMSS', '%Y-%m-%d %H%M%S'], 
        ]

        self.erasetype = [
 [_('Erase what ?'), _('None')],
 [_('All metadata'), 'a'],
 [_('All the Exif section'), 'e'],
 [_('ITPC Data only'), 'i'],
 [_('XMP Data only'), 'x'],
 [_('Exif thumbnails only'), 't'],
 [_('All Comments'), 'c'],
        ]

        # Populate objects
        for c in self.mimetype:
          self.mymime_store.append(c)
        self.mymimetype.set_active(0)
        self.myexiffield.set_active(0)

        for c in self.selecttype:
          self.myexif_compare.append(c)
        self.myselection.set_active(0)

        # For Date change
        self.do_ymd = go('do_ymd')
        self.mydy = go('mydy')
        self.mydm = go('mydm')
        self.mydd = go('mydd')
        self.mytime = go('mytime')

        # For Rename type selection
        self.rename_store = go('rename_store')
        self.do_rename = go('do_rename')
        self.myrename = go('myrename')
        for c in self.renameformat:
          c[0] = datetime.datetime.now().strftime(c[1])
          self.rename_store.append(c)
        self.myrename.set_active(0)

        # For Erase type selection
        self.erase_store = go('erase_store')
        self.do_erase = go('do_erase')
        self.myerase = go('myerase')
        for c in self.erasetype:
          self.erase_store.append(c)
        self.myerase.set_active(0)

        # Connect signals
        self.builder.connect_signals(self)

        # Everything is ready
        self.select_window.show()

    def picdir_changed(self, widget):
      # Any of the search criteria changed, reset button sensitivity
      self.search_files.set_sensitive(False)
      self.browse_meta.set_sensitive(False)
      self.next_step.set_sensitive(False)
      self.file_names = []
      self.filecount.set_text(_(' No files selected yet '))
      # Allow search if at least we have a directory and a mime type
      if (self.inputdirbutton.get_filename() and (self.mymimetype.get_active() > 0)):
        self.search_files.set_sensitive(True)

    def mydate_changed(self, widget):
      # Add/Subtract validated Years / Months / Days
      i = widget.get_text()
      j = self.get_num_signed(i)
      widget.set_text(j)
      if int('0' + self.get_num(j)) > 0:
        self.do_ymd.set_sensitive(True)

    def mytime_changed(self, widget):
      # Add/Subtract time [-]HH[:MM:[SS]]
      j = widget.get_text().strip().split(':')
      k = []
      for i in j:
        if len(k) == 0:
          n = self.get_num_signed(i)
          # Validate hours
          if int('0' + self.get_num(n)) > 23:
            n = '00'
          k.append(n)
        else:
          n = self.get_num(i)
          if len(k) == 1:
            if int('0' + n) > 60:
              n = '00'
          if len(k) == 2:
          # 61 seconds for occasional seconds added to time
            if int('0' + n) > 61:
              n = '00'
          k.append(n)
      j = ':'.join(k)
      widget.set_text(j)
      if int('0' + self.get_num(j)) > 0:
        self.do_ymd.set_sensitive(True)

    def rename_clicked(self, widget):
      # User just asked to rename files.
      if self.myrename.get_active() > 0:
        self.do_rename.set_sensitive(True)
      else:
        self.do_rename.set_sensitive(False)

    def erase_clicked(self, widget):
      # User just asked to rename files.
      if self.myerase.get_active() > 0:
        self.do_erase.set_sensitive(True)
      else:
        self.do_erase.set_sensitive(False)

    def show_meta(self, widget):
      # Open the metadata display window
      self.load_exif(0)
      self.window_meta.show()

    def hide_meta(self, widget, f=0):
      # Hide the metadata display window
      self.tag = 0
      self.window_meta.hide()

    def previous_file(self, widget):
      # Go back through the list of files stop at beginning
      self.tag = self.tag - 1
      self.load_exif(self.tag)
          
    def next_file(self, widget):
      # Go forward  through the list of files
      self.tag = self.tag + 1
      self.load_exif(self.tag)
      self.window_meta.show()

    def search_clicked(self, widget):
      # User clicked Search. Only possible if a mime-file type and a folder path are present
      self.scan_files(self)
      # If files were found, we can allow next step and show the metadata
      if len(self.file_names) > 0:
        self.browse_meta.set_sensitive(True)
        self.next_step.set_sensitive(True)

    def clear_search_clicked(self, widget):
      # User wants to start a new search
      self.inputdirbutton.set_filename(_('None'))
      self.includesubfolder.set_active(False)
      self.mymimetype.set_active(0)
      self.myexiffield.set_active(0)
      self.myselection.set_active(0)
      self.exifvalue.set_text('')
      self.filecount.set_text(_(' No files selected yet '))
      self.search_files.set_sensitive(False)
      self.browse_meta.set_sensitive(False)
      self.next_step.set_sensitive(False)
      self.file_names = []

    def show_picchange(self, widget):
      # Open the picture change window
      self.filechanges.set_text(_("You are now ready to make changes to the ") + ("%(FC)s" % {'FC':len(self.file_names)}) + _(" files you selected previously."))
      self.mydy.set_text('0')
      self.mydm.set_text('0')
      self.mydd.set_text('0')
      self.mytime.set_text('00:00:00')
      self.myerase.set_active(0)
      self.myrename.set_active(0)
      self.window_picchange.show()
      self.select_window.hide()

    def hide_picchange(self, widget):
      # Open the picture change window
      self.window_picchange.hide()
      self.select_window.show()

    def invoke(self,command):
      # Invoke command as a new system process and return its output.
      return Popen(command, stdout=PIPE, stdin=PIPE, shell=True).stdout.read()

    def get_num_signed(self,x):
      # Returns a string of a possibly signed (+-) integer number from user input
      y = x.strip()
      j = ''
      if x.find('-') >= 0:
        j = '-'
      i = ''.join(ele for ele in y if ele.isdigit())
      return j + i

    def get_num(self,x):
      # Returns a string of an integer number from user input
      return ''.join(ele for ele in x if ele.isdigit())

    def main_quit(self, widget):
      Gtk.main_quit()

    def about_clicked(self, m):
      self.aboutdialog1.run()
      self.aboutdialog1.hide()

    def donate_clicked(self, m):
      webbrowser.open_new_tab(DONATE)

    def on_success_button_clicked(self, m):
      self.success_dialog.hide()

    def on_emergency_button_clicked(self, m):
      self.emergency_dialog.hide()

# ------------------------------------------------------------------------
# Returns the existing mimetypes present in each directory from file_names
    def mimes_per_dir(self):
      d = {}
      for fn in self.file_names:
        a = fn.split(os.sep)
        ff = a.pop()
        ext = ff.split('.').pop()
        path = (os.sep).join(a)
        if d.get(path):
          saved = d[path].split('.')
          if ext not in saved:
            d[path] = d[path] + '.' + ext
        else:
          d[path] = '.' + ext
      return d

# ------------------------------------------------------------------------
    def load_exif(self, ind):
        # With exiv2, load the metadata from first file we find
        # (ind) is the record number
        # Result contains standard output. (exiv2 -pa image.jpg). Then cleanup the string

        result = self.invoke(EXIV2_LOCATION + ' -paq "'+ self.file_names[ind] + '"')
        result = (' '.join(((''.join(result)).replace("\n","|")).split())).split('|')
        self.mytree_store.clear()
        for x in result:
          if x:
            if x.startswith('Exif.'):
              tag = x.split(' ')[0]
              y1 = tag.split('Exif.')[1]
              b = x[len(tag):].strip()
              y2 = b.split(' ')[0]
              c = b[len(y2):].strip()
              y3 = c.split(' ')[0] 
              y4 = c[len(y3):].strip()
              self.mytree_store.append([y1, y2, y3, y4])

        fc = self.file_names[ind] + _(" (%(IND)s of %(TOT)s)" % {'IND':ind + 1, 'TOT':len(self.file_names)})
        if (len(self.mytree_store)) < 1:
          h = ("No Metadata available inside file\n") + fc
          self.headerlabel.set_text(h)
          self.headerlabel.set_markup('<span color="red">' + h + '</span>')
        else:
          self.headerlabel.set_text(_("File ") + fc)

        # Set navigation possible
        self.clickprevious.set_sensitive(True)
        self.clicknext.set_sensitive(True)
        if ind < 1:
          # Can go forward but not back
          self.clickprevious.set_sensitive(False)
        if (ind + 1) >= len(self.file_names):
          # Can go back but not forward
          self.clicknext.set_sensitive(False)

# ------------------------------------------------------------------------
# We have a path and a mime type, so find out how many files there are
    def scan_files(self, widget):
# Prepare to call exiv2 on each directory if we need to check for specific tag selection
      MimeType = self.mymimetype.get_active()
      MimeTypeText = self.mymime_store[MimeType][0]
      # Create a tuple of the file extensions in the group selected
      included_extentions = tuple(self.mymime_store[MimeType][1].split())
      self.file_names = []
      ExifField = self.myexiffield.get_active()
      ExifTag = self.myexiftags_store[ExifField][0]
      ExifFieldValue = self.exifvalue.get_text()
      action = self.myselection.get_active()
      ExifAction = self.myexif_compare[action][1]
      cmd = ''
      if (ExifField > 0) and action > 0:
        cmd = EXIV2_LOCATION + ' -Pkcv -q -g "' + ExifTag + '" '

      # Start at the user selected path, escape spaces in base directory name
      relevant_path = self.inputdirbutton.get_filename()
      subdirs = [relevant_path]

      # Add the directories to scan recursively
      # We do not escape spaces in directory names
      if self.includesubfolder.get_active():
        for root, dirnames, filenames in os.walk(relevant_path):
          for dd in dirnames:
            subdirs.append(os.path.join(root,dd))

      # Now scan each directory to find the selected mimetype files
      dd_type = []
      for dd in subdirs:
        thisdir_files = []
        fc = False
        exisearch = ['','','','','','']
        for fn in os.listdir(dd):
          if fn.endswith(included_extentions):
            fc = True            
            thisdir_files.append(os.path.join(dd, fn))
        # Now find the unique mime types found if requested
            ex = fn.split('.').pop()
            exisearch[included_extentions.index(ex)] = ex
        # Flag this directory as containing the right mimetype files 
        if fc:
          dd_type.append(exisearch)
        else:
          dd_type.append([''])

        # Now eliminate files not matching selected tag if user wanted it
        if cmd and fc:
          # Pass each unique mimetype found in this directory to the exiv2 command
          c = ''
          # exiv2 needs us to escape spaces in directory/file names
          de = '\ '.join(dd.split(' '))
          for t in exisearch:
            if t:
              c = c + de + os.sep + '*.' + t + " "
          result = self.invoke(cmd + c)
          result = (' '.join(((''.join(result)).replace("\n","|")).split())).split('|')
          thisdir_files = []
          for n in result:
            if n:
              a = n.split(' ' + ExifTag + ' ')
              b = a[1].split(' ')[1]
              if ExifAction == '=':
                if b == ExifFieldValue:
                   thisdir_files.append(a[0])
               # print 'Found =' + a[0] + '-with ' + b
              if ExifAction == '<>':
                if b <> ExifFieldValue:
                   thisdir_files.append(a[0])
              if ExifAction == '<':
                if b < ExifFieldValue:
                   thisdir_files.append(a[0])
              if ExifAction == '>':
                if b > ExifFieldValue:
                   thisdir_files.append(a[0])
              if ExifAction == 'is none':
                if not ExifFieldValue:
                   thisdir_files.append(a[0])
              if ExifAction == 'is not empty':
                if ExifFieldValue:
                   thisdir_files.append(a[0])
        # Add the selected files from this directory to the final file list
        if len(thisdir_files) > 0:
          self.file_names = self.file_names + thisdir_files

      # Any files found ?
      sfs = len(self.file_names)
      if sfs < 1:
          self.filecount.set_text(_('No files found matching the criteria selected'))

      else:
        c = _(" contains ")
        if self.includesubfolder.get_active():
          c = _(" and it's sub-folders contain ")
        self.filecount.set_text(_("Folder ") + relevant_path + c + ("%(FC)s" % {'FC':sfs}) + ' ' + MimeTypeText)
        self.search_files.set_sensitive(False)
        self.browse_meta.set_sensitive(True)
        # Clear garbage
        subdirs = []
        thisdir_files = []
        dd_type = []

# -------------------------------------------------------------------------
    def call_exiv2(self, ppf):
      # ppf is the formatted exiv2 command to execute with file name(s) to process
      # Call exiv2, get the console output and shell return code with values
      # 253 if no exif data, 255 if could not open file, 1 if an exiftag was not found
      proc = subprocess.Popen(ppf, shell=True, stderr=PIPE, preexec_fn=os.setsid)
      proc.wait()
      # Note : communicate() returns a tuple
      return [proc.returncode, proc.communicate()]

# -------------------------------------------------------------------------
    def do_wildcard(self, pp):
      # pp is the formatted exiv2 command to execute
      # exiv2 can process several wildcard input files. So, remove duplicate
      # directory names so we can do a wildcard search. e.g. if jpg and JPG 
      # files are in /mydir/ directory, this would be the command :
      # exiv2 (options) /mydir/*.jpg /mydir/*.JPG
      d = self.mimes_per_dir()
      err_list = []
      for dir in d:
        # exiv2 needs us to escape spaces in directory/file names
        dd = '\ '.join(dir.split(' '))
        ext = d[dir].split('.')
        se = ''
        for mime in ext:
          if mime:
            se = se + dd + os.sep + '*.' + mime + ' '
        console = self.call_exiv2(pp + se)
        if console[0] > 0:
#          err_list.append(_('Status (') + ("%(FC)s" % {'FC':console[0]}) + ')\n' + console[1][1])
          err_list.append(console[1][1])
      return err_list

# -------------------------------------------------------------------------
    def do_single(self, pp):
      # pp is the formatted exiv2 command to execute
      # exiv2 will process every single file individually because we
      # cannot use a wildcard file parameter for each directory
      err_list = []
      for se in self.file_names:
        # exiv2 needs us to escape spaces in directory/file names
        dd = '\ '.join(se.split(' '))
        console = self.call_exiv2(pp + dd)
        if console[0] > 0:
#          err_list.append(_('Status (') + ("%(FC)s" % {'FC':console[0]}) + ')\n' + console[1][1])
          err_list.append(console[1][1])
      return err_list

# -------------------------------------------------------------------------
    def do_ymd_clicked(self, widget):
      # Do the metadata date adjustments in files. We cannot get here unless
      # one of the Year, Month, Day or Time value is set
      parm = ''
      i = self.mydy.get_text()
      if i:
        parm = parm + '-Y ' + i + ' '
      i = self.mydm.get_text()
      if i:
        parm = parm + '-O ' + i + ' '
      i = self.mydd.get_text()
      if i:
        parm = parm + '-D ' + i + ' '
      i = self.mytime.get_text()
      if i:
        parm = parm + '-a ' + i + ' '
      if not parm:
        return False
      parm = EXIV2_LOCATION + ' ' + parm
      err_list = []
      # Use wildcard search if possible
      if self.myexiffield.get_active() < 1:
        err_list = self.do_wildcard(parm)
      else:
        err_list = self.do_single(parm)

      # Show any exiv2 errors reported
      if len(err_list) > 0:
        self.err_msg.set_text(_("Some files were not processed. These are the errors reported :\n\n") + "\n".join(err_list))
        self.emergency_dialog.run()
      else:
        self.ok_msg.set_text(_("The metadata requested has been set in the pictures / images successfully"))
        self.success_dialog.run()
      # Reset the adjustment values
      self.mydy.set_text('')
      self.mydm.set_text('')
      self.mydd.set_text('')
      self.do_ymd.set_sensitive(False)

# ------------------------------------------------------------------------
    def rename_files(self, widget):
        # Function to rename files based on date found in exif
        parm = EXIV2_LOCATION + ' -q -r "' + self.rename_store[self.myrename.get_active()][1] + '" mv '
        err_list = []
        # Use wildcard search if possible
        if self.myexiffield.get_active() < 1:
          err_list = self.do_wildcard(parm)
        else:
          err_list = self.do_single(parm)

        # Show any exiv2 errors reported
        if len(err_list) > 0:
          self.err_msg.set_text(_("Some files were not processed. These are the errors reported :\n\n") + "\n".join(err_list))
          self.emergency_dialog.run()
        else:
          self.ok_msg.set_text(_("The picture / image files were renamed successfully"))
          self.success_dialog.run()
        # Reset the form values
        self.myrename.set_active(0)
        self.do_rename.set_sensitive(False)

# -------------------------------------------------------------------------
    def erase_in_file(self, widget):
        # Function to delete metadata from file
        parm = EXIV2_LOCATION + ' -d' + self.erase_store[self.myerase.get_active()][1] + ' '
        err_list = []
        # Use wildcard search if possible
        if self.myexiffield.get_active() < 1:
          err_list = self.do_wildcard(parm)
        else:
          err_list = self.do_single(parm)

        # Show any exiv2 errors reported
        if len(err_list) > 0:
          self.err_msg.set_text(_("Some files were not processed. These are the errors reported :\n\n") + "\n".join(err_list))
          self.emergency_dialog.run()
        else:
          self.ok_msg.set_text(_("The metadata requested has been erased from the pictures / images successfully"))
          self.success_dialog.run()
        # Reset the form values
        self.myerase.set_active(0)
        self.do_erase.set_sensitive(False)

# -------------------------------------------------------------------------
if __name__ == '__main__':
    try:
        GUI = Exifgui()
        Gtk.main()
    except KeyboardInterrupt:
        pass

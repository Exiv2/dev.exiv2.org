#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <iostream>
#include <iomanip>
#include <cassert>

#include <QFileDialog>
#include <QFile>
#include <QDir>
#include <QDebug>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    QString fileName;




private slots:
    void on_actionLoad_Image_triggered();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H

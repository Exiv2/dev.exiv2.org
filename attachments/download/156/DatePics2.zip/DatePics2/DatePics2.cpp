// DatePics2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <exiv2/image.hpp>
#include <exiv2/exif.hpp>

enum 
{ OK = 0
, SYNTAX_ERROR
, CANNOT_OPEN
, CANNOT_READMETA_DATA
, CANNOT_FIND_TAG
} error = OK ;

int main(int argc, char* argv[])
{
	const char* filename = argv[1] ;
	const char*	result   = NULL    ;
	Exiv2::byte abytDateTimeDigitized[200];
	const char* tag = "Exif.Photo.DateTimeDigitized" ;
	
	if ( argc < 2 ) error = SYNTAX_ERROR ;
	if ( !error ) {
		Exiv2::ExifData exifData ;
		Exiv2::Image::AutoPtr image = Exiv2::ImageFactory::open (filename);
		if ( ! image.get() ) error = CANNOT_OPEN ; 

		if ( !error ) {
			image -> readMetadata ();
			exifData = image -> exifData ();
			if ( exifData.empty ()) error = CANNOT_READMETA_DATA ;
		}
		if ( !error ) {
			error = CANNOT_FIND_TAG ;

			Exiv2::ExifData::const_iterator end = exifData.end ();
			for ( Exiv2::ExifData::const_iterator i = exifData.begin (); i != end; ++i) {
				if (i -> key () == tag ) {
					i -> value ().copy (abytDateTimeDigitized, Exiv2::bigEndian);
				
					result = ( const char *) abytDateTimeDigitized;
					error = OK ;
				}
			}
		}
	}

	switch ( error ) {
		case	OK						: printf("%s => %s\n",filename,result) ; break ;
		case	SYNTAX_ERROR			: printf("syntax: DatePic2 filename\n") ; break ;
		case	CANNOT_OPEN				: printf("cannot open file: %s\n",filename) ; break ;
		case	CANNOT_READMETA_DATA	: printf("cannot read metadata: %s\n",filename) ; break ;
		case	CANNOT_FIND_TAG			: printf("cannot read tag %s from %s\n",tag,filename) ; break ;
		default							: printf("can't happen\n") ; break ;
	}

	return 0;
}


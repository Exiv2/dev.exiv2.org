Notes by Robin Mills

I've replaced the contents of main.cpp with <exiv2dir>/samples/exifprint.cpp

I build c:\gnu\exiv2\msvc64 from trunk

This code was in c:\robin\projects\exiv2linking\

There are 4 Configurations and two platforms

Configuration/Target Win32       x64
Debug             1) Compiled with /MTd  links exiv2sd.lib (static lib)
Release           1)               /MT          exiv2s.lib  (static lib)
DebugDLL          2)               /MDd         exiv2d.lib  (stub lib)
ReleaseDLL        2)               /MD          exiv2.lib   (stub lib)

1) No post build step is required.
2) Copy dlls from \gnu\exiv2\msvc64\exiv2lib\

Recommended use:

1) Reproduce/rebuild/retest the build (even create \robin\projects)
2) To move \gnu\exiv2\ to another location
   or      \robin\projects\exiv2linking
           Edit the exiv2linking: .sln and .vcxproj in a text editor

Still in difficulty?  

1) I can VNC/Skype to my computer and I will demonstrate this to you.
or
2) I can VNC/Skype to your computer and do demonstrate to you!

robin@clanmills.com
Time = 17:27:38  Date = Sun 25/Nov/2012

========================================================================
    CONSOLE APPLICATION : exiv2linking Project Overview
========================================================================

AppWizard has created this exiv2linking application for you.  

This file contains a summary of what you will find in each of the files that
make up your exiv2linking application.


exiv2linking.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

exiv2linking.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named exiv2linking.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////

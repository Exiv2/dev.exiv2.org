#include <QObject>
#include <QCoreApplication>
#include <QString>
#include <QThread>
#include <QFileInfo>
#include <QDir>
#include <QVector>
#include <QTimer>
#include <iostream>

#ifdef Q_OS_WIN
#include <Windows.h>
#endif
#include <exiv2/exiv2.hpp>

class MetadataReader: public QObject {
    Q_OBJECT
public:
    MetadataReader(const QString &filepath):
        m_Filepath(filepath)
    {}

private:
    void doWork() {
        Exiv2::Image::AutoPtr image = Exiv2::ImageFactory::open(m_Filepath.toStdString());
        image->readMetadata();

        Exiv2::XmpData &xmpData = image->xmpData();
        Exiv2::ExifData &exifData = image->exifData();
        Exiv2::IptcData &iptcData = image->iptcData();

        QThread::sleep(1);

        emit stopped();
    }

public slots:
    void process() { doWork(); }

signals:
    void stopped();

private:
    QString m_Filepath;
};

class Task : public QObject {
    Q_OBJECT
public:
    Task(const QString &dirPath, QObject *parent = 0):
        QObject(parent),
        m_DirPath(dirPath)
    {}

public slots:
    void run() {
        Exiv2::XmpParser::initialize();
        {
            doRun();
        }
        Exiv2::XmpParser::terminate();

        emit finished();
    }

private:
    void doRun() {
        QDir dir(m_DirPath);

        QStringList files = dir.entryList(QStringList() << "*.jpg");
        int count = files.count();
        QVector<QThread*> threads;

        for (int i = 0; i < count; ++i) {
            QString filepath = dir.filePath(files.at(i));
            MetadataReader *worker = new MetadataReader(filepath);
            QThread *thread = new QThread();
            worker->moveToThread(thread);

            QObject::connect(thread, SIGNAL(started()), worker, SLOT(process()));
            QObject::connect(worker, SIGNAL(stopped()), thread, SLOT(quit()));

            QObject::connect(worker, SIGNAL(stopped()), worker, SLOT(deleteLater()));
            QObject::connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));

            thread->start();
            threads.append(thread);
        }

        foreach (QThread *thread, threads) {
            thread->wait();
        }
    }

signals:
    void finished();

private:
    QString m_DirPath;
};

#include "main.moc"

int main(int argc, char *argv[]) {
    QCoreApplication app(argc, argv);

    if (argc < 2) {
        std::cout << "Not enough arguments" << std::endl;
        return 1;
    }

    QString directoryPath = app.arguments().at(1);

    if (!QDir(directoryPath).exists()) {
        std::cout << "Directory not found" << std::endl;
        return 1;
    }

    Task *task = new Task(directoryPath, &app);
    QObject::connect(task, SIGNAL(finished()), &app, SLOT(quit()));

    QTimer::singleShot(0, task, SLOT(run()));

    return app.exec();
}

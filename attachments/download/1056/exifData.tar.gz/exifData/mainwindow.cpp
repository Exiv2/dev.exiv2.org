#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <exiv2/exiv2.hpp>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionLoad_Image_triggered()
{
    fileName =  QFileDialog::getOpenFileName(this,tr("Open Image"), QDir::homePath(), tr("Image Files (*.png *.jpg *.bmp)"));
    QFile file(fileName);
    if(!file.exists()) return;
    Exiv2::Image::AutoPtr image = Exiv2::ImageFactory::open((const char*)fileName.toStdString().c_str(),sizeof(fileName.toStdString().c_str()));
}

